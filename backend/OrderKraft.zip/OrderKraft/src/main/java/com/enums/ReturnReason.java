package com.enums;

public enum ReturnReason {
    DAMAGED,
    WRONG_ITEM,
    NOT_AS_DESCRIBED,
    SIZE_ISSUE,
    OTHER
}
