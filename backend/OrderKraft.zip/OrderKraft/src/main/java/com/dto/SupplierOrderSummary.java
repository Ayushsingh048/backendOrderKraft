package com.dto;

public record SupplierOrderSummary(String supplierName, Long totalOrders) {}

