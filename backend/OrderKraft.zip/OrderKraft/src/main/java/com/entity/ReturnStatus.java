package com.entity;

public enum ReturnStatus {
    RAISED,
    SENT_TO_SUPPLIER,
    SUPPLIER_ACCEPTED,
    PROCESSED,
    REJECTED
}
