package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.entity.SupplierPerformance;

public interface SupplierPerformanceRepository extends JpaRepository<SupplierPerformance, Long> {

}
