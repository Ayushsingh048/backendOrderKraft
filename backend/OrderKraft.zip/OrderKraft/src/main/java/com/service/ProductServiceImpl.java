package com.service;

import com.dto.ProductDTO;
import com.entity.Product;
import com.repository.CategoryRepository;
import com.repository.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private CategoryRepository categoryRepo;

    @Override
    public Product createProduct(ProductDTO dto) {
    	Product product = new Product();
        product.setName(dto.getName());
        product.setDescription(dto.getDescription());
        product.setUnit_price(dto.getUnit_price());

        // Set Category only if category_id is provided
        if (dto.getCategory_id() != 0) {
            categoryRepo.findById(dto.getCategory_id()).ifPresent(product::setCategory);
        }

        return productRepo.save(product);
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepo.findAll();
    }

    @Override
    public Optional<Product> getProductById(Long id) {
        return productRepo.findById(id);
    }

    @Override
    public Optional<Product> getProductByName(String name) {
        return productRepo.findByName(name);
    }

    @Override
    public List<Product> getProductsByCategory_id(Long category_id) {
        return productRepo.findByCategory_CategoryId(category_id);
    }
}
